/**
 * @Filename: eth2.c
 * @Brief   :
 * @Author  : zhang.meiqing 
 * @Version : 1.0.0
 * @Date    : 06/27/2017 03:29:55 PM
 */
#include <linux/module.h>
#include <linux/init.h>

MODULE_LICENSE("GPL");

static int __init eth2_init(void)
{
    printk("eth module init\n");

    return 0;
}

static int __exit eth2_exit(void)
{
    printk("eth2 module exit\n");

    return 0;
}

module_init(eth2_init);
module_exit(eth2_exit);
